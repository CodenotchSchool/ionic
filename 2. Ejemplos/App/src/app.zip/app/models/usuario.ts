export class Usuario 
{
    constructor(public id: number, public nombre:string, public apellido1:string, public apellido2:string){}
} 


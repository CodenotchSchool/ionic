import { Component, OnInit } from '@angular/core';
import { Usuario } from '../models/usuario';
import { UsuarioService } from '../shared/usuario.service';

@Component({
  selector: 'app-vista',
  templateUrl: './vista.page.html',
  styleUrls: ['./vista.page.scss'],
})
export class VistaPage implements OnInit 
{
  public usuario : Usuario

  constructor(private apiService: UsuarioService) { }

  mostrarUsuario(id:number)
  {
      this.apiService.getUsuario(id).subscribe((data) => 
      {     
        this.usuario = data[0];
      }   
      )
      this.usuario = this.apiService.usuario;
  }  

  ngOnInit() {
  }

}
